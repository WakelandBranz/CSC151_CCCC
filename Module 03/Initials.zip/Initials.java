/*
program the solution in your eclipse IDE, when complete, create a zip file and upload it to Blackboard

Write a program that declares variables named init1, init2, and init3, to hold your three initials. Display the three initials with a period following each one, as in J.M.F. 
You can name the class Initials.java

When submitting the program for testing/grading, assign the values J, M, and F to init1, init2, init3, respectively.
 */

 public class Initials {
    public static void main(String[] args) {
        char init1 = 'J';
        char init2 = 'M';
        char init3 = 'F';
        
        System.out.println(init1 + "." + init2 + "." + init3 + ".");
    }
}